#ifndef SENSORS_H
#define SENSORS_H

/*****************************************************************************/
/*                                 DEFINES                                   */
/*****************************************************************************/
#define MMA6519_STATUS_OK               24064

#define READ_INC_ACC                    0xC0
#define WRITE_INC_ACC                   0x40
#define HACC_WRITE_BIT                  0x40
#define HACC_ODD_PARITY                 0x80
#define PRESSURE_I2C_ADDRESS            0xC0

#define I2C_WRITE                       0x00
#define I2C_READ                        0x01

#define HACC_READ_ERROR                 0xFFFF
#define HACC_MAX_NUMBER_OF_READ_RETRY   10

#define TEMP_SENSOR_CONSTANT            1832.0
#define TEMP_SUPPLY_VOLTAGE_MV          3300.0f
#define TEMP_NO_OF_ADC_DIVS             1023.0f
#define TEMP_MV_PER_DEGREE_CELCIUS      12.9f

/*****************************************************************************/
/*                                 TYPEDEFS                                  */
/*****************************************************************************/

/** \desc Structure holding all accelerometer data. */
typedef struct
{
    int x;
    int y;
    int z;
    int ha;
    /* Acceleration along rocket axis in [m/s^2]. */
    float a_axis;
} apAcceleration_t;

/*****************************************************************************/
/*                                FUNCTIONS                                  */
/*****************************************************************************/
inline void spi_init( void );
inline int spi_transmit( int aT_buffer );

inline void i2c2_init( void );
int i2c2_read( char *aR_buffer, int aBytesToRead );
int i2c2_transmit( char aT_buffer );
int i2c_command( int aCommand1, int aCommand2 );
int i2c_buffer_read( int aCommand, char *aR_buffer, int aBytesToRead );

void acc24g_config( void );
void read_acc24( apAcceleration_t *acc );
int acc80g_config( void );
int read_acc80( void );

void init_pressure( void );
float read_pressure( void );
float p2altitude( float aPressure );

inline float temp_calculate( unsigned int aMeasurement, int aOffset );

#endif
