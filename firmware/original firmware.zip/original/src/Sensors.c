/*****************************************************************************/
/*                                 INCLUDES                                  */
/*****************************************************************************/
#include <math.h>
#include <APlib.h>
#include <Sensors.h>
#include <dbg.h>

/*****************************************************************************/
/*                             GLOBAL VARIABLES                              */
/*****************************************************************************/
extern int ap_TimeoutI2C;
extern char ap_BufferError[BUFFER_ERROR_SIZE];

/*****************************************************************************/
/*                                FUNCTIONS                                  */
/*****************************************************************************/

/******************************************************************************
 * \brief Function initializes SPI.
 *
 * \input None.
 *
 * \output None.
 * ****************************************************************************/
inline void spi_init( void )
{
    /* Remapable pin configuration. */
    _SDI2R = RP_I_SENSE_SPI_MISO;   // MISO <=> RP5
    RP_O_SENSE_SPI_MOSI = 10;       // RP7  <=> MOSI
    RP_O_SENSE_SPI_SCK = 11;        // RP6  <=> SCK

    /* I/O configuration. */
    TRIS_ACC_CS = 0;                // ACC SPI CS = output
    ACC_CS = 1;                     // ACC SPI CS = 1
    TRIS_HACC_CS = 0;               // HACC SPI CS = output
    HACC_CS = 1;                    // HACC SPI CS = 1

    /* SPI driver configuration. */
    SPI2CON1bits.MODE16 = 0;        /* 1 = One word (16-bits) wide communication. */
    SPI2CON1bits.CKP = 0;           /* 1 = clock Idle state is high. */
    SPI2CON1bits.CKE = 1;           /* 1 = output data changes on transition from active clock to idle clock. */
    SPI2CON1bits.MSTEN = 1;         /* 1 = master mode. */
    SPI2CON1bits.SMP = 0;           /* 1 = data input sampled at end of data output time. */
    SPI2CON1bits.SPRE = 6;          /* Secondary prescale, 6 - 2:1. */
    SPI2CON1bits.PPRE = 2;          /* Primary prescale, 2 - 4:1. */
    SPI2STATbits.SPIROV = 0;        /* Clear receive overflow. */
    SPI2STATbits.SPIEN = 1;         /* Enable SPI1. */
}

/******************************************************************************
 * \brief Function transmits one byte to SPI.
 *
 * \input int aT_byte
 *      Byte to be transmitted.
 *
 * \output
 *      Byte received from slave during transmission.
 * ****************************************************************************/
inline int spi_transmit( int aT_byte )
{
    SPI2BUF = aT_byte;
    while( !SPI2STATbits.SPIRBF );
    return SPI2BUF;
}

/******************************************************************************
 * \brief Function initializes I2C.
 *
 * \input None.
 *
 * \output None.
 * ****************************************************************************/
inline void i2c2_init( void )
{
    /* 40@16MHz = 200 kHz */
    I2C2BRG = 80;
    I2C2CONbits.I2CEN = 1;
}    

/******************************************************************************
 * \brief Function reads data from I2C bus.
 *
 * \input char *aR_buffer
 *      Pointer to buffer to write received data.
 *
 * \input int aBytesToRead
 *      Number of bytes to read.
 *
 * \output
 *      Return value:
 *          0 - OK,
 *          1 - Timeout.
 * ****************************************************************************/
int i2c2_read( char *aR_buffer, int aBytesToRead )
{
    int i;
    I2C2CONbits.ACKDT = 0;
    for( i = 0; i < ( aBytesToRead - 1 ); i++ )
    {
        I2C2CONbits.RCEN = 1;
        ap_TimeoutI2C = 2;
        while( I2C2CONbits.RCEN )
        {
            if( ap_TimeoutI2C == 0 )
            {
                return 1;
            }
        }
        aR_buffer[i] = I2C2RCV;
        I2C2CONbits.ACKEN = 1;
        while( I2C2CONbits.ACKEN );
    }
    
    I2C2CONbits.RCEN = 1;
    ap_TimeoutI2C = 2;
    while( I2C2CONbits.RCEN )
    {
        if( ap_TimeoutI2C == 0 )
        {
            return 1;
        }
    }
    
    aR_buffer[i] = I2C2RCV;
    I2C2CONbits.ACKDT = 1;
    I2C2CONbits.ACKEN = 1;
    while( I2C2CONbits.ACKEN );
    return 0;
}

/******************************************************************************
 * \brief Function sends one byte to I2C bus.
 *
 * \input char aT_byte
 *      Byte to send.
 *
 * \output
 *      Return value:
 *          0 - OK,
 *          1 - NACK received.
 * ****************************************************************************/
int i2c2_transmit( char aT_byte )
{
    I2C2TRN = aT_byte;
    while( I2C2STATbits.TRSTAT );
    
    if( I2C2STATbits.ACKSTAT )
    {
        /* NACK received. */
        I2C2CONbits.PEN = 1;
        while( I2C2CONbits.PEN );
        return 1;
    }
    return 0;
}

/******************************************************************************
 * \brief Function sends one two-byte command (with implicit address) to I2C bus.
 *
 * \input int aCommand1
 *      First byte of command.
 *
 * \input int aCommand2
 *      Second byte of command.
 *
 * \output
 *      Return value:
 *          0 - OK,
 *          1 - NACK received.
 * ****************************************************************************/
int i2c_command( int aCommand1, int aCommand2 )
{
    /* Send I2C start. */
    I2C2CONbits.SEN = 1;
    while( I2C2CONbits.SEN );
    
    if( i2c2_transmit( PRESSURE_I2C_ADDRESS | I2C_WRITE ) )
    {
        return 1;
    }
    if( i2c2_transmit( aCommand1 ) )
    {
        return 1;
    }
    if( i2c2_transmit( aCommand2 ) )
    {
        return 1;
    }
    /* Send I2C stop. */
    I2C2CONbits.PEN = 1;
    while( I2C2CONbits.PEN );
    I2C2STAT = 0;
    return 0;
}

/******************************************************************************
 * \brief Function reads larger block of data from I2C bus.
 *
 * \input int aCommand
 *      Command byte to send before read.
 *
 * \input char *aR_buffer
 *      Pointer to buffer to save received data.
 *
 * \input int aBytesToRead
 *      Number of bytes to read.
 *
 * \output
 *      Return value:
 *          0 - OK,
 *          1 - NACK received.
 * ****************************************************************************/
int i2c_buffer_read( int aCommand, char *aR_buffer, int aBytesToRead )
{
    int rv;
    /* Send I2C start. */
    I2C2CONbits.SEN = 1;
    while( I2C2CONbits.SEN );

    /* Send address. */
    if( i2c2_transmit( PRESSURE_I2C_ADDRESS | I2C_WRITE ) )
    {
        return 1;
    }

    /* Send command. */
    if( i2c2_transmit( aCommand ) )
    {
        return 1;
    }

    /* Send restart (change of data direction). */
    I2C2CONbits.RSEN = 1;
    while( I2C2CONbits.RSEN );

    /* Send address. */
    if( i2c2_transmit( PRESSURE_I2C_ADDRESS | I2C_READ ) )
    {
        return 1;
    }
    rv = i2c2_read( aR_buffer, aBytesToRead );
    check_debug( rv == 0, "I2C read error" );

    /* Send I2C stop. */
    I2C2CONbits.PEN = 1;
    while( I2C2CONbits.PEN );
    I2C2STAT = 0;
    return 0;
    
error:
    return 1;
}

/******************************************************************************
 * \brief Function initializes and configures low-g accelerometer.
 *
 * \input None.
 *
 * \output None.
 * ****************************************************************************/
void acc24g_config( void )
{
    /* Configure SPI for low-g accelerometer. */
    SPI2CON1bits.CKP = 1;
    SPI2CON1bits.CKE = 0;

    /* Select low-g accelerometer. */
    ACC_CS = 0;
    Nop();
    spi_transmit( 0x20 + WRITE_INC_ACC );
    Nop();
    spi_transmit( 0b00101111 );
    Nop();
    spi_transmit( 0b00000000 );
    Nop();
    spi_transmit( 0b00000000 );
    Nop();
    spi_transmit( 0b11110000 );
    Nop();
    /* Deselect low-g accelerometer. */
    ACC_CS = 1;
}

/******************************************************************************
 * \brief Function Reads data from low-g accelerometer.
 *
 * \input apAcceleration_t *acc
 *      Pointer to structure containing accelerometer data.
 *
 * \output None.
 * ****************************************************************************/
void read_acc24( apAcceleration_t *acc )
{
    /* Configure SPI for low-g accelerometer. */
    SPI2CON1bits.CKP = 1;
    SPI2CON1bits.CKE = 0;

    /* Select low-g accelerometer. */
    ACC_CS = 0;
    Nop();
    spi_transmit( 0x28 + READ_INC_ACC );
    Nop();
    acc->x = ( ( spi_transmit( 0 ) << 8 ) + spi_transmit( 0 ) ) >> 4;
    Nop();
    acc->y = ( ( spi_transmit( 0 ) << 8 ) + spi_transmit( 0 ) ) >> 4;
    Nop();
    acc->z = ( ( spi_transmit( 0 ) << 8 ) + spi_transmit( 0 ) ) >> 4;
    Nop();
    /* Deselect low-g accelerometer. */
    ACC_CS = 1;
}

/******************************************************************************
 * \brief Function initializes and configures high-g accelerometer.
 *
 * \input None.
 *
 * \output
 *      Return value from accelerometer. Based on this a check can be done if
 *      accelerometer is connected and working.
 * ****************************************************************************/
int acc80g_config( void )
{
    int acc_data;
    /* Number of iteration in which Arecorder is trying to connect to
     * accelerometer. */
    int repeat = 0;
    /* Return value from accelerometer. */
    int hacc_present;

    /* Configure SPI for high-g accelerometer. */
    SPI2CON1bits.CKP = 0;
    SPI2CON1bits.CKE = 1;
    
    do
    {
        HACC_CS = 0;
        
        /* Read DEVSTAT register. */
        hacc_present = ( spi_transmit( 0b10010100 ) << 8 ) + spi_transmit( 0b00000000 );
        HACC_CS = 1;
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        repeat++;
        if( repeat >= HACC_MAX_NUMBER_OF_READ_RETRY )
        {
            break;
        }
    }
    while(hacc_present != 19969);
    
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    HACC_CS = 0;
    /* Low pass filter 50 Hz on Y axis. */
    acc_data = ( spi_transmit( 0b01001101 ) << 8 ) + spi_transmit( 0x08 );
    HACC_CS = 1;
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    HACC_CS = 0;
    /* Raw, unsigned data, end of initialization. */
    acc_data = ( spi_transmit( 0b01001011 ) << 8 ) + spi_transmit( 0b10110000 );
    HACC_CS = 1;
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    Nop();
    HACC_CS = 0;
    /* Raw, unsigned data, end of initialization. Repeated.
     * Since now every write to configuration register will be discarded. */
    acc_data = ( spi_transmit( 0b01001011 ) << 8 ) + spi_transmit( 0b10110000 );
    HACC_CS = 1;
        
    return hacc_present;
}

/******************************************************************************
 * \brief Function Reads data from high-g accelerometer.
 *
 * \input None.
 *
 * \output Measured acceleration.
 * ****************************************************************************/
int read_acc80( void )
{
    /* Number of iteration in which Arecorder is trying read data from
     * accelerometer. */
    int repeat = 0;
    /* Temporary register. */
    int temp;
    /* Measured acceleration. */
    int hacc;

    /* Configure SPI for high-g accelerometer. */
    SPI2CON1bits.CKP = 0;
    SPI2CON1bits.CKE = 1;
    do
    {
        if( repeat > HACC_MAX_NUMBER_OF_READ_RETRY )
        {
            return HACC_READ_ERROR;
        }
        HACC_CS = 0;

        /* Y-axis acc (X-axis of Arecorder). */
        temp = spi_transmit( 0b10010100 );
        hacc = ( spi_transmit( 0b00000000 ) << 2 ) + ( ( temp & 0b11000000 ) >> 6 )
               + ( ( temp & 0b00000011 ) << 10 ) - 2096;
        HACC_CS = 1;
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        HACC_CS = 0;

        /* Read DEVSTAT register. */
        temp = ( spi_transmit( 0b01110000 ) << 8 ) + spi_transmit( 0b00001100 );
        HACC_CS = 1;
        repeat++;
    }
    while( temp != MMA6519_STATUS_OK );
    return hacc;
}

/******************************************************************************
 * \brief Function initializes and configures pressure sensor.
 *
 * \input None.
 *
 * \output None.
 * ****************************************************************************/
void init_pressure( void )
{
    i2c_command( 0x2C, 0b10000000 );
    i2c_command( 0x26, 0b00001010 );
}    

/******************************************************************************
 * \brief Function Reads data from pressure sensor.
 *
 * \input None.
 *
 * \output
 *      1 - error.
 *      any other value - measured pressure.
 * ****************************************************************************/
float read_pressure( void )
{
    /* Return value from I2C bus. */
    int rv;
    /* Buffer for reading data from I2C bus. */
    static unsigned int PressureRaw[3];
    /* Buffer for reading data from I2C bus. */
    static char I2cReadRaw[3];
    /* Returned pressure. */
    float CalculatedPressure;

    rv = i2c_buffer_read( 0x01, I2cReadRaw, 3 );
    check( rv == 0, "I2C read error." );
    rv = i2c_command( 0x26, 0b00001010 );
    check( rv == 0, "I2C read error." );
    PressureRaw[0] = ( int )I2cReadRaw[0] & 0x00ff;
    PressureRaw[1] = ( int )I2cReadRaw[1] & 0x00ff;
    PressureRaw[2] = ( int )I2cReadRaw[2] & 0x00ff;
#ifdef PRESSURE_CAN_BE_NEGATIVE
    CalculatedPressure = (long int)( PressureRaw[0] & 0x7F )*1024 + (long int)( PressureRaw[1]*4 ) + (long int)( PressureRaw[2] >> 6 );
    if( ( PressureRaw[0] >> 7 ) == 1 )
    {
        CalculatedPressure = CalculatedPressure | ( (long)0xFF << 24 ) | ( (long)0xFE << 16 );
    }
    return CalculatedPressure;
#else
    return ( float )( PressureRaw[0] )*1024 + ( PressureRaw[1]*4 ) + ( PressureRaw[2] >> 6 );
#endif
error:
    return 1;
}

/******************************************************************************
 * \brief Function calculates altitude from pressure.
 *
 * \input float aPressure
 *      Pressure from which altitude is calculated.
 *
 * \output
 *      Calculated altitude.
 * ****************************************************************************/
float p2altitude( float aPressure )
{
    return PRESSURE_COEFF_1*( 1 - powf( ( aPressure/P_SEA_LEVEL ), PRESSURE_COEFF_2 ) );
}

/******************************************************************************
 * \brief Function calculates temperature from voltage measurement.
 *
 * \input unsigned int aMeasurement
 *      Raw voltage measurement.
 *
 * \input int aOffset
 *      Temperature offset.
 *
 * \output
 *      Calculated altitude.
 * ****************************************************************************/
inline float temp_calculate( unsigned int aMeasurement, int aOffset )
{
    return ( TEMP_SENSOR_CONSTANT -
           ( TEMP_SUPPLY_VOLTAGE_MV/TEMP_NO_OF_ADC_DIVS*aMeasurement ) )/TEMP_MV_PER_DEGREE_CELCIUS
           - aOffset;
}
